//  (c) Copyright 2009 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-------------------------------------------------------------------


/* Include files */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "video_utils.h"
#include "bmp_utils.h"
#include "rgb_utils.h"
#include "yuv_utils.h"
#include "gen_stim.h"
#include "v_rgb2ycrcb_v7_1_bitacc_cmodel.h"

#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#pragma warning( disable : 4996 )

#ifdef NT
#define SLASH '\\'
#else
#ifdef _WIN32
#define SLASH '\\'
#else
#define SLASH '/'
#endif
#endif

#ifndef _MAX_PATH
#define _MAX_PATH 2048
#endif

#ifndef uint32
#define uint32 unsigned int
#endif

// These variables control how the C model randomizes stimuli:
int RAND_ORIG=0;          // Controls whether the location of the origin of the frame is randomized between transactions
int RAND_ACTIVE_SIZE=0;   // Controls whether the active size is randomized between transactions

int print_help(void)
{
  printf("\nUsage: run_bitacc_cmodel in_file out_path \n\n");
  printf("       in_file     : path/name of the input file (24-bit RGB BMP file)\n");
  printf("       out_path    : path to to the output files\n");
  return(0);
}
int bmp_processing(char* in_filename, char* output_path)
{
//  static struct rgb8_video_struct rgb8_in_video;
//  static struct rgb8_video_struct rgb8_out_video;
  struct  xilinx_ip_v_rgb2ycrcb_v7_1_generics generics;
  struct  xilinx_ip_v_rgb2ycrcb_v7_1_inputs   inputs;
//  struct  xilinx_ip_v_rgb2ycrcb_v7_1_outputs  outputs; 
  char in_bin_filename[_MAX_PATH] = { 0 }; 
  char out_bin_filename[_MAX_PATH] = { 0 }; 
  FILE* input_bmp=NULL; 
  FILE* input_bin=NULL; 
  FILE* output_bmp=NULL;
  FILE* output_bin=NULL;
  int  ret_val = 2;     // Corresponds to memory allocation error
//  int row, col, color;

  // Initialize generics and inputs structure with defaults:
  if ((ret_val = xilinx_ip_v_rgb2ycrcb_v7_1_get_default_generics(&generics))>0) return(ret_val);
  generics.STANDARD_SEL = 3; // Set to YUV Standard
  generics.OUTPUT_RANGE = 2;  // Set to 0_to_255_for_Computer_Graphics
  set_standard_generics(&generics);

  if ((ret_val = xilinx_ip_v_rgb2ycrcb_v7_1_get_default_inputs(&generics, &inputs))>0) return(ret_val); 

  // Set input parameters to SD_ITU_601
  inputs.COEF_IN.ACOEF = 0.2568;
  inputs.COEF_IN.BCOEF = 0.0979;
  inputs.COEF_IN.CCOEF = 0.5910;
  inputs.COEF_IN.DCOEF = 0.5772;
  rgb2ycrcb_coefficient_translation(&(inputs.COEF_IN), &(inputs.COEF_OUT));

  inputs.ACTIVE_COLS = 64;
  inputs.ACTIVE_ROWS = 64;

  ret_val=gen_stim( &generics, &inputs, in_filename, output_path, 1, 1);
  return(ret_val);
}

int main( int argc, char* argv[] )
{
  char in_filename[_MAX_PATH] = { 0 }; 
  char out_path[_MAX_PATH] = { 0 }; 
  char in_ext[16];
  struct  xilinx_ip_v_rgb2ycrcb_v7_1_generics generics_2;
  int  ret_val_2 = 2;
//  char out_ext[16];
//  char *c;

  if ((ret_val_2 = xilinx_ip_v_rgb2ycrcb_v7_1_get_default_generics(&generics_2))>0) return(ret_val_2);
  if (argc<3) exit(print_help()); 

  strcpy(in_filename,  argv[1]);
  strcpy(out_path, argv[2]);

  strcpy( in_ext, strrchr(in_filename,'.')+1 );
  if (strcmp(in_ext, "bmp")==0) { return(bmp_processing(in_filename, out_path));
  }
  else {
    printf("\nInput file format not recognized!\n");
    return(16);
  }
  return(0);
}
